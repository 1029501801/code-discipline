#!/usr/bin/env python3
"""Find implementations that may already cover a capability, before writing new code.

Searches a repository for function / class / interface definitions whose names match
the given capability terms, then ranks them by name similarity. Use it as the first
step of the "reuse before rewrite" rule: search by capability, not by the name you
were about to invent.

Usage:
    python scan_reuse.py <root> --terms "format,date"
    python scan_reuse.py ./src --terms "upload,retry" --ext .ts,.py --top 30
    python scan_reuse.py . --terms "parse" --json

Options:
    --terms    Comma-separated capability words (verbs or nouns). Required.
    --ext      Comma-separated extensions to scan. Default: common source exts.
    --top      Max results to print. Default 25.
    --json     Emit JSON instead of a table.
    --all      Include low-confidence matches (score < 0.45).
"""

import argparse
import difflib
import json
import os
import re
import sys

DEFAULT_EXTS = [
    ".py", ".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs", ".vue", ".svelte",
    ".go", ".java", ".kt", ".cs", ".scala", ".rs", ".php", ".rb",
]

SKIP_DIRS = {
    "node_modules", ".git", ".hg", ".svn", "dist", "build", "out", ".next", ".nuxt",
    "coverage", "__pycache__", ".venv", "venv", "env", "target", "vendor", ".idea",
    ".vscode", ".gradle", ".mypy_cache", ".pytest_cache", "bin", "obj", "Pods",
    ".workbuddy-ai", "migrations",
}

SHARED_DIR_HINTS = ["utils", "util", "common", "shared", "helpers", "helper", "lib",
                    "core", "internal", "pkg", "infra", "base"]

# Definition patterns keyed by a coarse language family.
PATTERNS = {
    "py": [
        re.compile(r"^\s*(?:async\s+)?def\s+(\w+)"),
        re.compile(r"^\s*class\s+(\w+)"),
    ],
    "js": [
        re.compile(r"\b(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s+(\w+)"),
        re.compile(r"\b(?:export\s+)?(?:const|let|var)\s+(\w+)\s*(?::[^=]+)?=\s*(?:async\s*)?(?:\([^)]*\)|\w+)\s*(?::[^=;{]+)?=>"),
        re.compile(r"\b(?:export\s+)?(?:default\s+)?(?:abstract\s+)?class\s+(\w+)"),
        re.compile(r"\b(?:export\s+)?(?:interface|type|enum)\s+(\w+)"),
        re.compile(r"^\s{2,}(?:(?:public|private|protected|static|async|readonly|override|get|set)\s+)*(\w+)\s*\([^)]*\)\s*(?::[^={]+)?\{"),
    ],
    "go": [
        re.compile(r"^func\s+(?:\([^)]*\)\s*)?(\w+)"),
        re.compile(r"^type\s+(\w+)\s+"),
    ],
    "jvm": [
        re.compile(r"^\s*(?:public|private|protected|internal)\s+(?:static\s+)?(?:final\s+)?[\w<>\[\],.?\s]+\s+(\w+)\s*\("),
        re.compile(r"^\s*(?:public|private|protected|internal)?\s*(?:abstract\s+)?(?:class|interface|enum|record)\s+(\w+)"),
    ],
    "rs": [
        re.compile(r"^\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?(?:const\s+)?fn\s+(\w+)"),
        re.compile(r"^\s*(?:pub(?:\([^)]*\))?\s+)?(?:struct|trait|enum)\s+(\w+)"),
    ],
    "php": [
        re.compile(r"^\s*(?:(?:public|private|protected|static|final|abstract)\s+)*function\s+(\w+)\s*\("),
        re.compile(r"^\s*(?:abstract\s+|final\s+)?(?:class|interface|trait)\s+(\w+)"),
    ],
    "rb": [
        re.compile(r"^\s*def\s+(?:self\.)?(\w+[?!=]?)"),
        re.compile(r"^\s*(?:class|module)\s+(\w+)"),
    ],
}

FAMILY_BY_EXT = {
    ".py": "py",
    ".js": "js", ".jsx": "js", ".ts": "js", ".tsx": "js", ".mjs": "js",
    ".cjs": "js", ".vue": "js", ".svelte": "js",
    ".go": "go",
    ".java": "jvm", ".kt": "jvm", ".cs": "jvm", ".scala": "jvm",
    ".rs": "rs", ".php": "php", ".rb": "rb",
}

# Names that carry no capability signal.
STOP_NAMES = {
    "get", "set", "run", "main", "init", "setup", "start", "stop", "close", "open",
    "update", "handle", "process", "execute", "apply", "call", "invoke", "create",
    "delete", "remove", "add", "list", "find", "load", "save", "build", "make",
    "tostring", "valueof", "constructor", "render", "component", "props", "state",
    "index", "default", "test", "tests", "mock", "fixture", "demo", "example",
}

# Control-flow keywords that a loose method pattern may capture.
CONTROL_NAMES = {
    "if", "for", "while", "switch", "catch", "function", "return", "new", "else",
    "do", "try", "with", "super", "await", "typeof", "throw", "case", "finally",
}


def tokenize(name):
    """Split camelCase / snake_case / kebab-case / digit boundaries into tokens."""
    parts = re.split(r"[_\-.\s]+", name)
    tokens = []
    for part in parts:
        tokens.extend(re.findall(r"[A-Z]+(?=[A-Z][a-z])|[A-Z]?[a-z]+|[A-Z]+|\d+", part))
    return [t.lower() for t in tokens if t]


def score(name, terms):
    lowered = name.lower()
    name_tokens = set(tokenize(name))
    best = 0.0
    for term in terms:
        t = term.lower().strip()
        if not t:
            continue
        if lowered == t:
            return 1.0
        term_tokens = set(tokenize(t))
        if term_tokens and term_tokens <= name_tokens:
            best = max(best, 0.90)
        if len(t) >= 3 and t in lowered:
            best = max(best, 0.80)
        if term_tokens:
            overlap = len(term_tokens & name_tokens)
            if overlap:
                best = max(best, 0.55 + 0.30 * (overlap / len(term_tokens)))
        ratio = difflib.SequenceMatcher(None, lowered, t).ratio()
        if ratio >= 0.72:
            best = max(best, ratio * 0.82)
    return round(best, 3)


def collect_files(root, exts):
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for fn in filenames:
            if os.path.splitext(fn)[1].lower() in exts:
                files.append(os.path.join(dirpath, fn))
    return files


def extract(path, family):
    try:
        if os.path.getsize(path) > 2 * 1024 * 1024:
            return []
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            lines = fh.readlines()
    except OSError:
        return []

    found = []
    patterns = PATTERNS.get(family, [])
    for lineno, line in enumerate(lines, 1):
        if len(line) > 400:
            continue
        for pattern in patterns:
            match = pattern.search(line)
            if match:
                name = match.group(1)
                if name.lower() in CONTROL_NAMES:
                    break
                found.append((name, lineno, line.strip()[:160]))
                break
    return found


def main():
    parser = argparse.ArgumentParser(description="Find existing implementations by capability.")
    parser.add_argument("root", help="Repository or source directory to scan")
    parser.add_argument("--terms", required=True, help="Comma-separated capability words")
    parser.add_argument("--ext", default=None, help="Comma-separated extensions, e.g. .ts,.py")
    parser.add_argument("--top", type=int, default=25)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--all", action="store_true", help="Include low-confidence matches")
    args = parser.parse_args()

    if not os.path.isdir(args.root):
        print(f"error: not a directory: {args.root}", file=sys.stderr)
        return 2

    terms = [t.strip() for t in args.terms.split(",") if t.strip()]
    if not terms:
        print("error: --terms is empty", file=sys.stderr)
        return 2

    if args.ext:
        exts = {e.strip().lower() if e.strip().startswith(".") else "." + e.strip().lower()
                for e in args.ext.split(",") if e.strip()}
    else:
        exts = set(DEFAULT_EXTS)

    files = collect_files(args.root, exts)
    results = []
    for path in files:
        family = FAMILY_BY_EXT.get(os.path.splitext(path)[1].lower())
        if not family:
            continue
        for name, lineno, snippet in extract(path, family):
            if len(name) < 3 or name.lower() in STOP_NAMES:
                continue
            s = score(name, terms)
            if s < (0.3 if args.all else 0.45):
                continue
            results.append({
                "symbol": name,
                "score": s,
                "file": os.path.relpath(path, args.root).replace(os.sep, "/"),
                "line": lineno,
                "signature": snippet,
            })

    # De-duplicate identical symbol+file, keep the first occurrence.
    seen = set()
    unique = []
    for item in sorted(results, key=lambda r: (-r["score"], r["file"], r["line"])):
        key = (item["symbol"], item["file"])
        if key in seen:
            continue
        seen.add(key)
        unique.append(item)

    top = unique[: args.top]

    shared_dirs = []
    for dirpath, dirnames, _ in os.walk(args.root):
        for d in list(dirnames):
            if d in SKIP_DIRS:
                dirnames.remove(d)
                continue
            if d.lower() in SHARED_DIR_HINTS:
                shared_dirs.append(os.path.relpath(os.path.join(dirpath, d), args.root).replace(os.sep, "/"))

    if args.json:
        print(json.dumps({"terms": terms, "scanned_files": len(files),
                          "matches": top, "shared_dirs": shared_dirs[:20]},
                         ensure_ascii=False, indent=2))
        return 0

    print(f"Scanned {len(files)} files under {args.root}")
    print(f"Terms: {', '.join(terms)}")
    if not top:
        print("\nNo candidate found.")
        print("Before writing a new implementation, also try:")
        print("  1. different terms (synonyms, English/Chinese pairs)")
        print("  2. grepping the shared dirs listed below for call sites, not definitions")
    else:
        print()
        width = max(len(r["symbol"]) for r in top)
        for r in top:
            loc = f'{r["file"]}:{r["line"]}'
            print(f'  {r["score"]:.2f}  {r["symbol"].ljust(width)}  {loc}')
            print(f'        {r["signature"]}')

    if shared_dirs:
        print("\nShared dirs worth reading before deciding to write new code:")
        for d in shared_dirs[:20]:
            print(f"  {d}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
