#!/usr/bin/env python3
"""Heuristic self-check for the four failure modes this skill guards against.

This is a hint generator, not a linter. Every finding is a question to answer,
not a verdict: some catches are legitimate, some interfaces have one implementation
for good reason. The point is to make the questionable lines visible before delivery.

Usage:
    python audit_code.py src/service/order.ts src/common/date.ts
    python audit_code.py ./src --ext .ts,.py
    python audit_code.py ./src --json

Checks:
    swallowed-exception    catch/except whose body is empty or only logs
    silent-default         env/config lookup with an inline fallback value
    single-impl-interface  interface / abstract class with 0 or 1 implementors
    long-function          function body longer than 80 lines

Exit code is always 0 unless arguments are invalid.
"""

import argparse
import json
import os
import re
import sys

SKIP_DIRS = {
    "node_modules", ".git", "dist", "build", "out", ".next", "coverage",
    "__pycache__", ".venv", "venv", "target", "vendor", ".idea", ".vscode",
}
DEFAULT_EXTS = [".py", ".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".go", ".java", ".kt"]

LOG_CALL = re.compile(r"^(?:console|logger|log|logging|print|printk)\s*(?:\.\w+\s*)?\(")
JS_CATCH = re.compile(r"\bcatch\s*(?:\([^)]*\))?\s*\{")
JS_FUNC = re.compile(
    r"(?:^|\s)(?:export\s+)?(?:default\s+)?(?:async\s+)?function\s+(\w+)\s*\("
    r"|^\s{2,}(?:(?:public|private|protected|static|async|readonly|override)\s+)*(\w+)\s*\([^;]*\)\s*(?::[^={]+)?\{"
)
PY_DEF = re.compile(r"^(\s*)(?:async\s+)?def\s+(\w+)\s*\(")
PY_EXCEPT = re.compile(r"^(\s*)except\b[^:]*:")
PY_INTERFACE = re.compile(r"\binterface\s+(\w+)|abstract\s+class\s+(\w+)")
PY_ABC_CLASS = re.compile(r"^\s*class\s+(\w+)\s*\(([^)]*)\)")

ENV_DEFAULT_PATTERNS = [
    (re.compile(r"process\.env\.\w+\s*\|\|"), "process.env.X || fallback"),
    (re.compile(r"process\.env\.\w+\s*\?\?"), "process.env.X ?? fallback"),
    (re.compile(r"os\.getenv\(\s*['\"][^'\"]+['\"]\s*,"), "os.getenv('X', default)"),
    (re.compile(r"os\.environ\.get\(\s*['\"][^'\"]+['\"]\s*,"), "os.environ.get('X', default)"),
    (re.compile(r"System\.getenv\(\s*\"[^\"]+\"\s*,"), "System.getenv(\"X\", default)"),
    (re.compile(r"os\.Getenv\(\s*\"[^\"]+\"\s*\)\s*==\s*\"\""), "os.Getenv fallback"),
]

LONG_FUNCTION_LINES = 80


def read_lines(path):
    try:
        if os.path.getsize(path) > 2 * 1024 * 1024:
            return None
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            return fh.readlines()
    except OSError:
        return None


def brace_body(lines, start_idx, open_col=0):
    """Given a line containing an opening brace, return (end_idx, statements).

    open_col is the offset of that opening brace, so a leading '}' from a
    preceding block is not miscounted. Statements are split on ';' and newlines,
    which is enough to tell an empty body from a one-statement body.
    """
    depth = 0
    started = False
    statements = []
    buf = ""
    for i in range(start_idx, min(len(lines), start_idx + 400)):
        line = lines[i]
        begin = open_col if i == start_idx else 0
        for ch in line[begin:]:
            if ch == "{":
                depth += 1
                started = True
                continue
            if ch == "}":
                depth -= 1
                if depth <= 0:
                    if buf.strip():
                        statements.append(buf.strip())
                    return i, statements
                continue
            if not started:
                continue
            if ch in ";\n":
                if buf.strip():
                    statements.append(buf.strip())
                buf = ""
            else:
                buf += ch
        if started and buf.strip():
            statements.append(buf.strip())
            buf = ""
    return start_idx, statements


def indent_of(line):
    return len(line) - len(line.lstrip())


def rel_display(path):
    """Relative path when it stays inside the cwd; absolute otherwise."""
    absolute = os.path.abspath(path).replace(os.sep, "/")
    try:
        rel = os.path.relpath(path).replace(os.sep, "/")
    except ValueError:
        return absolute
    return absolute if rel.startswith("..") else rel


def check_swallowed_js(lines):
    findings = []
    for i, line in enumerate(lines):
        match = JS_CATCH.search(line)
        if not match:
            continue
        _end, statements = brace_body(lines, i, match.end() - 1)
        if not statements:
            findings.append((i + 1, "swallowed-exception", "空 catch，异常被完全丢弃", line.strip()))
        elif len(statements) == 1 and LOG_CALL.match(statements[0]):
            findings.append((i + 1, "swallowed-exception",
                             "catch 后只打日志，错误不再向上传播", statements[0][:120]))
    return findings


def check_swallowed_py(lines):
    findings = []
    i = 0
    while i < len(lines):
        match = PY_EXCEPT.match(lines[i])
        if not match:
            i += 1
            continue
        base_indent = len(match.group(1))
        body = []
        j = i + 1
        while j < len(lines):
            if lines[j].strip() and indent_of(lines[j]) <= base_indent:
                break
            if lines[j].strip() and not lines[j].strip().startswith("#"):
                body.append(lines[j].strip())
            j += 1
        if not body or (len(body) == 1 and (body[0] == "pass" or LOG_CALL.match(body[0]))):
            detail = "except: pass" if not body or body[0] == "pass" else "except 后只打日志"
            findings.append((i + 1, "swallowed-exception", detail, lines[i].strip()))
        i = max(j, i + 1)
    return findings


def check_silent_default(lines):
    findings = []
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("//") or stripped.startswith("#"):
            continue
        for pattern, label in ENV_DEFAULT_PATTERNS:
            if pattern.search(line):
                findings.append((i + 1, "silent-default", f"必填配置带兜底值：{label}", stripped[:120]))
                break
    return findings


def check_long_functions(lines, family):
    findings = []
    if family == "py":
        for i, line in enumerate(lines):
            match = PY_DEF.match(line)
            if not match:
                continue
            base_indent = len(match.group(1))
            end = i
            j = i + 1
            while j < len(lines):
                if lines[j].strip() and indent_of(lines[j]) <= base_indent:
                    break
                end = j
                j += 1
            length = end - i + 1
            if length > LONG_FUNCTION_LINES:
                findings.append((i + 1, "long-function",
                                 f"{match.group(2)} 有 {length} 行，考虑按步骤拆分", line.strip()[:120]))
        return findings

    for i, line in enumerate(lines):
        match = JS_FUNC.search(line)
        if not match:
            continue
        name = match.group(1) or match.group(2)
        if not name or name in {"if", "for", "while", "switch", "catch"}:
            continue
        end, _ = brace_body(lines, i, match.end() - 1)
        length = end - i + 1
        if length > LONG_FUNCTION_LINES:
            findings.append((i + 1, "long-function",
                             f"{name} 有 {length} 行，考虑按步骤拆分", line.strip()[:120]))
    return findings


def check_interfaces(paths):
    """Collect declared interfaces/abstract classes and count implementors across the tree."""
    declared = []
    for path, lines, family in paths:
        for i, line in enumerate(lines):
            match = PY_ABC_CLASS.match(line) if family == "py" else PY_INTERFACE.search(line)
            if not match:
                continue
            if family == "py":
                bases = match.group(2)
                if "ABC" not in bases and "Protocol" not in bases:
                    continue
                declared.append((match.group(1), path, i + 1))
            else:
                name = match.group(1) or match.group(2)
                if not name:
                    continue
                brace_at = line.find("{")
                if brace_at >= 0:
                    _end, statements = brace_body(lines, i, brace_at)
                    body_text = " ".join(statements)
                    # Pure data shapes (DTO / props / type literals) are not abstraction layers.
                    if not re.search(r"(?:^|\s)\w+\s*\([^)]*\)\s*:", body_text):
                        continue
                declared.append((name, path, i + 1))

    findings = []
    for name, path, lineno in declared:
        impl = re.compile(r"(?:implements|extends)\s+" + re.escape(name) + r"\b")
        base = re.compile(r"class\s+\w+\s*\(\s*" + re.escape(name) + r"\b")
        count = 0
        locations = []
        for other_path, lines, _family in paths:
            for i, line in enumerate(lines):
                if impl.search(line) or base.search(line):
                    count += 1
                    locations.append(f"{os.path.basename(other_path)}:{i + 1}")
        if count <= 1:
            detail = ("没有任何实现或继承" if count == 0
                      else f"只有 1 个实现（{locations[0]}），确认是否真的需要抽象")
            findings.append((path, lineno, "single-impl-interface", f"{name}：{detail}"))
    return findings


def main():
    parser = argparse.ArgumentParser(description="Heuristic self-check before delivering code.")
    parser.add_argument("paths", nargs="+", help="Files or directories to audit")
    parser.add_argument("--ext", default=None, help="Comma-separated extensions when given a directory")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if hasattr(sys.stdout, "reconfigure"):
        try:
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        except (ValueError, OSError):
            pass

    exts = set(DEFAULT_EXTS)
    if args.ext:
        exts = {e.strip().lower() if e.strip().startswith(".") else "." + e.strip().lower()
                for e in args.ext.split(",") if e.strip()}

    files = []
    for target in args.paths:
        if os.path.isfile(target):
            files.append(target)
        elif os.path.isdir(target):
            for dirpath, dirnames, filenames in os.walk(target):
                dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
                for fn in filenames:
                    if os.path.splitext(fn)[1].lower() in exts:
                        files.append(os.path.join(dirpath, fn))
        else:
            print(f"error: no such file or directory: {target}", file=sys.stderr)
            return 2

    loaded = []
    for path in files:
        lines = read_lines(path)
        if lines is None:
            continue
        ext = os.path.splitext(path)[1].lower()
        family = "py" if ext == ".py" else ("js" if ext in {".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"} else "other")
        loaded.append((path, lines, family))

    per_file = {}
    for path, lines, family in loaded:
        found = []
        if family == "py":
            found += check_swallowed_py(lines)
        elif family == "js":
            found += check_swallowed_js(lines)
        found += check_silent_default(lines)
        found += check_long_functions(lines, family)
        if found:
            per_file[path] = found

    interface_findings = check_interfaces(loaded)

    if args.json:
        payload = {
            "scanned_files": len(loaded),
            "file_findings": [
                {"file": path, "findings": [
                    {"line": ln, "rule": rule, "detail": detail, "snippet": snippet}
                    for ln, rule, detail, snippet in items]}
                for path, items in per_file.items()
            ],
            "interface_findings": [
                {"file": path, "line": ln, "rule": rule, "detail": detail}
                for path, ln, rule, detail in interface_findings
            ],
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    total = sum(len(v) for v in per_file.values()) + len(interface_findings)
    print(f"Audited {len(loaded)} files, {total} hint(s).")
    print("Hints are questions, not verdicts. Answer each one or change the code.\n")

    for path, items in per_file.items():
        print(rel_display(path))
        for ln, rule, detail, snippet in sorted(items):
            print(f"  L{ln:<5} {rule:<22} {detail}")
            if snippet:
                print(f"         {snippet}")
        print()

    if interface_findings:
        print("Abstractions")
        for path, ln, rule, detail in interface_findings:
            print(f"  {rel_display(path)}:{ln}  {detail}")
        print()

    if total == 0:
        print("Clean on these checks. Still answer the five questions in SKILL.md.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
