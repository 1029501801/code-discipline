# 形状：抽象与自明性

抽象和可读性是一件事的两面：**抽象决定读者要跳几次，结构决定读者能不能顺着读下去。**

## 一、抽象只有三个合法来源

| 来源 | 判据 | 例子 |
|---|---|---|
| 真实重复 | 同样的逻辑已经出现 3 次 | 三个模块都在做金额分转元 |
| 真实变化 | 已有 2 个变体，且确定还会增加 | 已支持微信、支付宝，下季度接银联 |
| 外部集成点 | 需要替换实现以便测试 | 支付网关要在单测里 mock |

三条都不满足，就是**提前抽象**。提前抽象的问题不是"多写了代码"，而是**猜错了变化的方向**——你按想象中的变化设计了接口，真实变化来的时候接口照样要改，还多了一层要改。

## 二、抽象决策树

```
现在有几个实现 / 变体？
├─ 1 个，且没有已排期的第二个
│   └─ 用具体类 + 参数。不加接口。
├─ 1 个，但它是外部依赖（DB、第三方 API、文件系统）
│   └─ 抽接口，因为测试需要替换。只抽这一个，不要连带抽它的上下游。
├─ 2 个，且变化点是"整段逻辑不同"
│   └─ 用策略/多态。此时抽象是被证据支持的。
├─ 2 个，但变化点只是"某个参数不同"
│   └─ 用参数或配置，不要上策略模式。
└─ 3 个以上
    └─ 抽象。此时你已经知道真正的变化轴在哪。
```

配套的反问：

- 如果只有一个实现，把这个接口删掉，代码会变短还是变长？**变短 → 删掉。**
- 这个 `Factory` 现在返回的类是不是永远只有一个？是 → 它现在是个常量。
- 这个 `Manager` 里有没有任何一行代码不是转发？没有 → 它是纯粹的中间人。

## 三、层数预算

把"调用层数"当预算花。一个请求链路，从入口到数据，**超过 4 层就要解释理由**：

```
Controller → Service → Repository → DB          ✅ 正常
Controller → Facade → AppService → DomainService → Repository → Mapper → DB   ❌ 需要理由
```

每多一层，读代码的人多跳一次，改一个字段要多改一个文件。层数不是能力的证明，是成本。

## 四、自明性：让主线可读

### 反例：每行都对，整体读不懂

```ts
async function handle(data: any, ctx: any) {
  let result: any = {};
  const cfg = getCfg();
  try {
    if (data && data.type) {
      if (data.type === 'A') {
        const t = data.list.filter((x: any) => x && x.status !== 0);
        if (t.length > 0) {
          let sum = 0;
          for (const i of t) { sum += i.amount * (cfg.rate ?? 1); }
          result.total = sum;
          result.count = t.length;
        } else { result.total = 0; result.count = 0; }
      } else {
        result = await other(data);
      }
    } else { return null; }
  } catch (e) { console.log(e); return null; }
  return result;
}
```

问题清单：`data`/`ctx`/`result`/`cfg`/`t`/`i` 全都不承载信息；三层嵌套 + 一个 for 循环混在业务判断里；`cfg.rate ?? 1` 在掩盖配置缺失；catch 后返回 null 让调用方无从判断；`ctx` 参数根本没用。

### 正例：主线一眼可见

```ts
type SettlementInput = { type: 'A' | 'B'; items: OrderItem[] };

async function settle(input: SettlementInput): Promise<Settlement> {
  if (input.type === 'B') return settleByRule(input.items);
  return settleByAmount(input.items);
}

function settleByAmount(items: OrderItem[]): Settlement {
  const valid = items.filter(isBillable);
  const total = valid.reduce((sum, i) => sum + i.amount * config.taxRate, 0);
  return { total, count: valid.length };
}

function isBillable(item: OrderItem): boolean {
  return item.status !== OrderStatus.VOID;
}
```

改了什么：

- 入口函数只剩**分支决策**，读三行就知道有两种结算方式。
- 每个步骤函数名说清"做什么"，读者不需要进函数体也能理解流程。
- 校验收敛到 `isBillable` 一个地方，语义明确（不是 `status !== 0` 这种魔法值）。
- 配置缺失不再兜底 —— `config.taxRate` 由启动时校验保证存在。
- 没有 try-catch：异常交给全局处理器，`input` 的类型由边界校验保证。
- 类型替代 `any`，`ctx` 这种没用上的参数直接删掉。

## 五、坏味道速查

| 坏味道 | 症状 | 处理 |
|---|---|---|
| 单一实现接口 | `interface X` 只有一个 `implements` | 删接口，直接用类 |
| 纯转发层 | `Manager.method()` 只调 `Service.method()` | 删掉这一层，调用方直达 |
| 三字段 Builder | 对象只有 3 个字段却用 Builder 链式构造 | 用对象字面量 / 命名参数 |
| 策略模式单分支 | `strategies` 里只有一个 key | 用参数或直接调用 |
| 过度泛型 | `<T extends Record<string, unknown>>` 只被一种类型实例化 | 写具体类型 |
| 抽象基类 | `BaseXxx` 只有一个子类，且没有共享状态 | 用组合或工具函数 |
| 辅助方法瀑布 | 主流程调用 5 个只有一个调用点的私有方法 | 内联回主流程，只保留有名字价值的 |
| 双重封装 | `getUser()` 内部调 `this.repo.find()` 再 `map()` 再 `pick()` | 合并成一个查询 + 一次映射 |
| 命名无信息 | `data`、`res`、`result`、`temp`、`list2`、`obj` | 换成承载业务含义的名词 |

## 六、一个自检动作

重构或收尾时，做一次**删减试验**：

> 依次注释掉每个新增的辅助方法 / 接口 / 抽象类，看主流程是否仍然成立。

- 注释后编译通过、主流程可读 → 它没有存在必要，删掉。
- 注释后主流程变乱 → 它承担了真实的表达职责，保留。

这个动作比"看起来是否专业"可靠得多，因为它在测**必要性**，而不是测审美。
