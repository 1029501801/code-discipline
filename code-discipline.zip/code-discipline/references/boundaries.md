# 边界：防御写在哪，异常交给谁

防御性代码不是错，错在**位置**。判空、校验、catch 都有明确的责任方，写在错误的位置就会变成噪音，而噪音会掩盖真正的问题。

## 一、信任边界矩阵

"信任边界"= 外部数据第一次进入系统的位置。边界上校验，边界内信任。

| 数据来源 | 谁负责校验 | 边界内怎么处理 |
|---|---|---|
| HTTP 请求体 / query / path | Controller 层的 DTO + 校验装饰器 | Service 直接使用，不再判空 |
| 消息队列 / 事件 | 消费者入口，反序列化后立即校验 | 后续 handler 信任消息结构 |
| 第三方回调（支付、Webhook） | 回调入口：验签 + 字段校验 | 业务处理信任数据 |
| 文件上传 | 上传入口：类型、大小、数量 | 处理逻辑信任文件可用 |
| 配置文件 / 环境变量 | **启动时**一次性加载并校验 | 全局使用已校验的强类型配置对象 |
| 数据库读取 | Schema 层：NOT NULL / 外键 / 唯一 | 代码里信任字段非空 |
| 内部函数调用 | 调用方（契约由签名声明） | 被调用方不重复校验 |

反过来说：**如果你在一个不在上表"来源"列的位置写了校验，先确认它是不是重复的。**

## 二、校验一次

```ts
// ❌ 三处重复校验，真正的空值问题反而被淹没
async cancelOrder(orderId?: string) {
  if (!orderId) throw new Error('orderId required');        // Controller 已校验
  const order = await this.repo.findById(orderId);
  if (!order) return null;                                  // 上层无法区分"不存在"和"已取消"
  if (!order.userId) { logger.warn('no userId'); return; }   // schema 已 NOT NULL
  ...
}

// ✅ 边界校验一次，内部用契约
// controller: CancelOrderDto { @IsUUID() orderId: string }
async cancelOrder(orderId: string) {
  const order = await this.repo.findById(orderId);
  if (!order) throw new NotFoundError('ORDER_NOT_FOUND', { orderId });  // 明确语义，让上层处理
  if (order.status !== 'PENDING') throw new BizError('ORDER_NOT_CANCELLABLE');
  ...
}
```

两个要点：

1. **"不存在"要抛错，不要返回 null**。返回 null 把判断责任推给每个调用方，最终每个调用方都会写一遍 `if (!x) return`。
2. **不要用 `logger.warn` 代替抛错**。日志不是控制流。

## 三、异常分三层

| 类型 | 例子 | 处理方式 |
|---|---|---|
| 业务异常（可预期） | 库存不足、重复下单、无权限 | 抛自定义 `BizError`，由全局异常处理器转成 4xx + 错误码 |
| 系统异常（不可预期） | DB 连接失败、第三方超时 | 直接抛，让全局处理器记录完整堆栈并返回 5xx |
| 可恢复的局部失败 | 批量任务里单条失败、可选服务降级 | 在**能真正补救的那一层** catch，并让失败可见 |

### 什么时候该 catch

只有三种情况：

1. **要转换**：把底层异常转成领域异常，保留 cause。
   ```ts
   try { await this.payment.refund(id); }
   catch (e) { throw new PaymentRefundError('REFUND_FAILED', { id, cause: e }); }
   ```
2. **要降级**：有明确的替代路径，且降级是可接受的业务决策。
   ```ts
   const cached = await this.cache.get('rate').catch(() => null);
   const rate = cached ?? (await this.fetchRate());
   // 注意：这里 catch 的是缓存不可用，不是业务失败
   ```
3. **要保证清理**：`finally` 释放资源。

### 什么时候不该 catch

- 只想打条日志然后继续 → 全局处理器已经会打，重复打会让堆栈断在这里
- 想把错误"吞掉"让流程走下去 → 这是静默降级，线上最难排查的一类 bug
- 因为"不确定这里会不会抛" → 那就去确认，不要用 try 兜住未知

```ts
// ❌ 最常见的坏味道：吞掉 + 继续
try { await this.syncInventory(order); } catch (e) { logger.error(e); }
await this.markAsPaid(order);   // 库存没同步成功，但订单已标记支付

// ✅ 要么让它中断，要么显式记录为可观测的失败
await this.syncInventory(order).catch((e) => {
  this.failedJobs.push({ orderId: order.id, reason: e.message });  // 进入补偿队列
});
```

## 四、配置：缺失即失败

```ts
// ❌ 三种静默兜底，线上配置错了也发现不了
const secret = process.env.JWT_SECRET || 'dev-secret';
const timeout = Number(process.env.TIMEOUT ?? 3000);
const dbUrl = process.env.DB_URL?.trim() ?? '';

// ✅ 启动时加载一次，缺失直接崩，报清楚缺哪个
const config = loadConfig({
  JWT_SECRET: requiredString(),
  DB_URL: requiredUrl(),
  TIMEOUT_MS: optionalNumber(3000),   // 有业务语义的默认值才允许
});
```

判断一个默认值是否合法，只问一句：**这个默认值被用上时，系统行为还是正确的吗？**

- `pageSize` 默认 20 → 正确，是业务约定 ✅
- `JWT_SECRET` 默认 `'dev-secret'` → 生产环境等于没有鉴权 ❌
- `DB_URL` 默认空串 → 会在连接时才炸，且堆栈指向无关位置 ❌

`.trim()` 也一样：只在"用户可能手滑输入空格"的边界（表单、粘贴的密钥）用，不要给每个配置都套一层。

## 五、日志打在哪一层

| 层 | 打什么 | 不打什么 |
|---|---|---|
| 边界（Controller / 消费者） | 请求标识、关键入参摘要、耗时 | 完整请求体（脱敏成本高、体积大） |
| 领域层 | 业务状态跃迁（订单 A → 已取消） | 每个方法进出（噪音） |
| 基础设施层 | 外部调用、耗时、重试次数 | 已由全局处理器记录的异常堆栈 |

原则：**一条错误链路只打一次完整堆栈**。中间层只补充上下文（`orderId`、`userId`、`attempt`），不重复打堆栈。

## 六、对照速查

| AI 默认写法 | 成熟项目里该有的写法 |
|---|---|
| `if (!x) return null` | `if (!x) throw new NotFoundError(...)` |
| `catch (e) { console.log(e) }` | 不 catch，或转成领域异常抛出 |
| `process.env.X \|\| 'default'` | 启动时校验，缺失即失败 |
| 每个 public 方法都判一遍入参 | 边界校验一次，内部信任 |
| `try { ... } catch { return [] }` | 让异常上抛，或显式标记降级 |
| `value?.trim() ?? ''` 到处出现 | 只在真实的外部输入处做清洗 |
| 用 `logger.warn` 记录异常后继续 | 抛错，或写入补偿队列 |
