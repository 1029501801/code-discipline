# 复用：先找到，再决定

"先搜索已有实现"这条规则本身没用 —— 搜索需要正确的词，而 AI 往往用自己准备新建的名字去搜，当然搜不到。搜索要按**能力**搜，不是按名字搜。

## 一、把能力拆成搜索词

先问"我要做的这件事，本质是什么动作 + 什么对象"，再套同义词。

| 能力 | 搜索词 |
|---|---|
| 格式化/解析 | format, parse, stringify, serialize, deserialize, toJSON, fromJSON, normalize |
| 校验 | validate, verify, check, assert, is[A-Z], schema, rule, constraint |
| 请求/网络 | fetch, request, http, axios, client, api, retry, timeout, abort |
| 缓存 | cache, memo, memoize, store, lru, ttl, redis |
| 节流/重试 | throttle, debounce, retry, backoff, poll, interval |
| 文件 | upload, download, export, import, readFile, writeFile, stream |
| 分页/列表 | paginate, page, cursor, limit, offset, slice |
| 转换/映射 | map, transform, convert, to[Type], adapter, mapper |
| 日期时间 | date, time, dayjs, moment, duration, timezone, timestamp |
| 权限 | auth, permission, role, guard, can, policy, acl |
| 错误 | error, exception, AppError, BizError, throw, handle |

命令示例：

```bash
# 按能力扫，一次给多个词
python scripts/scan_reuse.py ./src --terms "format,date,time"

# 也可以直接 grep 定义处，比全文搜噪音小
grep -rn "export function\|export const\|^def \|^export class" src/utils src/common src/shared
```

**必查目录**：`utils/ common/ shared/ helpers/ lib/ core/ internal/ pkg/`。这些目录的存在本身就是信号 —— 有 utils 目录说明项目已有复用文化，先去那里找。

## 二、吻合度判定树

找到候选后，按这个顺序判断，不要跳步：

```
候选实现是否存在？
├─ 否 → 新建，放公共层（见第三节）
└─ 是
   ├─ 逻辑一致，只是入参形态不同？
   │   ├─ 是 → 扩展现有实现：加可选参数 / 加重载 / 加适配器
   │   └─ 否
   ├─ 覆盖了我要的 70% 以上？
   │   ├─ 是 → 扩展。在原函数上加参数，别在旁边复制一份改名
   │   └─ 否
   ├─ 只是"同一类问题"但规则不同（如两种货币换算规则）？
   │   ├─ 是 → 新建，但和它放在同一目录、同一命名体系
   │   └─ 否 → 新建
```

关键判断：**"改它会不会伤到现有调用方？"** 不会 → 改它。会 → 加参数并给默认值保持兼容，或新建。

### 扩展的三种正当方式

```ts
// 1. 可选参数 + 默认值（最常用，成本最低）
export function formatDate(d: Date, pattern = 'YYYY-MM-DD'): string

// 2. 重载 / 联合类型（入参形态差异大时）
export function parseAmount(v: string): number
export function parseAmount(v: number): number

// 3. 策略参数（行为差异被真实使用过两次以上）
export function sortBy<T>(list: T[], key: keyof T, dir: 'asc' | 'desc' = 'asc')
```

反面方式：复制一份改个名字。`formatDate` → `formatDateV2` → `formatDateNew`，这是技术债的经典开端。

## 三、代码放哪一层

| 这段逻辑的特征 | 放在 | 命名 |
|---|---|---|
| 不依赖任何业务概念（字符串、日期、金额计算） | 公共层 `common/utils/` | `formatDate`、`parseAmount` |
| 依赖一个业务实体，但被多个模块用（订单号规则） | 领域层 `domain/order/` | `buildOrderNo` |
| 只服务当前模块的一个流程 | 当前模块内的私有函数 | `resolveCancelReason` |
| 与外部系统交互（支付、短信、对象存储） | 集成层 `infra/` 或 `clients/` | `PaymentClient.refund` |

**判定口诀**：把函数名里的业务词删掉，如果还说得通 → 它属于公共层；如果删掉就不知道在干什么 → 它属于业务层。

- `formatDate` → 删掉没有业务词 → 公共层 ✅
- `formatOrderDate` → 删掉 `Order` 仍是 `formatDate` → 说明业务词是多余的，应放公共层 ✅
- `resolveCancelReason` → 删掉 `Cancel` 就不成立 → 业务层 ✅

## 四、什么时候该复制，而不是复用

复用不是无条件正确的。以下情况复制更划算：

1. **两份逻辑只是碰巧长得像，变化方向不同**。强行合并会得到一个充满 `if (scene === 'A')` 的函数，之后每次改动都要考虑另一边。
2. **耦合成本高于重复成本**。为了复用 20 行代码，引入跨模块依赖、循环依赖风险，不值得。
3. **其中一份是临时逻辑**（活动页、一次性迁移脚本）。临时逻辑不该污染公共层。

判断标准：**它们未来会不会一起变？** 会 → 合并。不会 → 分开。

## 五、第二次重复怎么办

不要立刻提取，也不要假装没看见。留标记：

```ts
// 与 service/user/avatar.ts 的压缩逻辑重复，第三次出现时提取到 common/image.ts
```

这样第三次出现时，搜索 `重复，第三次` 就能定位所有副本。比"我记得好像哪里写过"可靠。
